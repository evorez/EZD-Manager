#!/system/bin/sh
# Magisk / KernelSU installer entrypoint. The CI workflow places companion.apk here.
ui_print "- Installing EZD Manager module"
if [ -f "$MODPATH/companion.apk" ]; then
  if command -v pm >/dev/null 2>&1 && pm install -r "$MODPATH/companion.apk" >/dev/null 2>&1; then
    ui_print "- EZD Manager APK installed"
  else
    ui_print "! APK install deferred; it will be retried after Android finishes booting"
    touch "$MODPATH/.apk_install_pending"
  fi
else
  ui_print "! companion.apk missing; this is an incomplete module package"
  abort "Rebuild the module zip using the CI workflow."
fi
ui_print "- No device tuning is applied by this foundation build"
